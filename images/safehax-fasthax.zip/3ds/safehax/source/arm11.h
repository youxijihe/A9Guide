#pragma once

void arm11_start(void);
void arm11_end(void);
