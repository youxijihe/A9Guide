#ifndef __UTIL_H
#define __UTIL_H

void wait_for_user(void);

#endif /* __UTIL_H */
